package com.example.s8109282assignment2.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.s8109282assignment2.data.BooksRepository
import com.example.s8109282assignment2.data.model.BookEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import retrofit2.HttpException

sealed class DashboardState {
    object Loading : DashboardState()
    data class Data(val list: List<BookEntity>) : DashboardState()
    data class Error(val message: String) : DashboardState()
}

class DashboardViewModel(private val repo: BooksRepository) : ViewModel() {
    private val _state = MutableStateFlow<DashboardState>(DashboardState.Loading)
    val state: StateFlow<DashboardState> = _state

    fun load(keypass: String) {
        _state.value = DashboardState.Loading
        viewModelScope.launch {
            try {
                val res = repo.dashboard(keypass)
                _state.value = DashboardState.Data(res.entities)
            } catch (e: Exception) {
                val msg = when (e) {
                    is HttpException -> "HTTP ${e.code()} ${e.message()}"
                    else -> e.message ?: "Unknown error"
                }
                _state.value = DashboardState.Error("Failed: $msg")
            }
        }
    }
}

