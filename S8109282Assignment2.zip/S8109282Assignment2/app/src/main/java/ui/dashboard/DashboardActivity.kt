package com.example.s8109282assignment2.ui.dashboard

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.s8109282assignment2.data.model.BookEntity
import com.example.s8109282assignment2.databinding.ActivityDashboardBinding
import com.example.s8109282assignment2.ui.detail.DetailActivity
import com.example.s8109282assignment2.ui.login.ObserverStarter
import org.koin.androidx.viewmodel.ext.android.viewModel

class DashboardActivity : ComponentActivity() {

    private lateinit var binding: ActivityDashboardBinding
    private val vm: DashboardViewModel by viewModel()
    private val adapter = BooksAdapter(::openDetail)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.rvBooks.layoutManager = LinearLayoutManager(this)
        binding.rvBooks.adapter = adapter

        val keypass = intent.getStringExtra("keypass") ?: ""
        if (keypass.isEmpty()) {
            Toast.makeText(this, "Missing keypass", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        vm.load(keypass)

        lifecycle.addObserver(ObserverStarter(vm.state) { state ->
            when (state) {
                is DashboardState.Loading -> binding.progress.visibility = View.VISIBLE
                is DashboardState.Data -> {
                    binding.progress.visibility = View.GONE
                    adapter.submit(state.list)
                }
                is DashboardState.Error -> {
                    binding.progress.visibility = View.GONE
                    Toast.makeText(this, state.message, Toast.LENGTH_LONG).show()
                }
            }
        })
    }

    private fun openDetail(item: BookEntity) {
        startActivity(Intent(this, DetailActivity::class.java).apply {
            putExtra("title", item.property1)
            putExtra("author", item.property2)
            putExtra("summary", item.description)
        })
    }
}
