package com.example.s8109282assignment2.ui.dashboard

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.s8109282assignment2.data.model.BookEntity
import com.example.s8109282assignment2.databinding.ItemBookBinding

class BooksAdapter(private val onClick: (BookEntity) -> Unit)
    : RecyclerView.Adapter<BooksAdapter.VH>() {

    private val data = mutableListOf<BookEntity>()

    fun submit(list: List<BookEntity>) {
        data.clear(); data.addAll(list); notifyDataSetChanged()
    }

    inner class VH(val b: ItemBookBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(item: BookEntity) {
            b.tvTitle.text = item.property1
            b.tvAuthor.text = "by ${item.property2}"
            b.root.setOnClickListener { onClick(item) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val inf = LayoutInflater.from(parent.context)
        return VH(ItemBookBinding.inflate(inf, parent, false))
    }

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(data[position])
    override fun getItemCount() = data.size
}
