package com.example.s8109282assignment2.ui.detail

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge
import com.example.s8109282assignment2.databinding.ActivityDetailBinding

class DetailActivity : ComponentActivity() {
    private lateinit var binding: ActivityDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val title = intent.getStringExtra("title").orEmpty()
        val author = intent.getStringExtra("author").orEmpty()
        val summary = intent.getStringExtra("summary").orEmpty()

        binding.tvTitle.text = title
        binding.tvAuthor.text = "by $author"
        binding.tvSummary.text = summary
    }
}

