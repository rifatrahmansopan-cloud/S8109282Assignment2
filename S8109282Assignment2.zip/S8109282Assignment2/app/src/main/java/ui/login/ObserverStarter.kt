package com.example.s8109282assignment2.ui.login

import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class ObserverStarter<T>(
    private val flow: StateFlow<T>,
    private val onValue: (T) -> Unit
) : DefaultLifecycleObserver {
    override fun onStart(owner: LifecycleOwner) {
        owner.lifecycleScope.launch { flow.collect { value -> onValue(value) } }
    }
}

