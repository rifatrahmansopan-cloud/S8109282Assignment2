package com.example.s8109282assignment2.ui.login

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.s8109282assignment2.data.BooksRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import retrofit2.HttpException

sealed class LoginState {
    object Idle : LoginState()
    object Loading : LoginState()
    data class Success(val keypass: String) : LoginState()
    data class Error(val message: String) : LoginState()
}

class LoginViewModel(private val repo: BooksRepository) : ViewModel() {
    private val _state = MutableStateFlow<LoginState>(LoginState.Idle)
    val state: StateFlow<LoginState> = _state

    fun login(campus: String, username: String, password: String) {
        _state.value = LoginState.Loading
        viewModelScope.launch {
            try {
                val res = repo.login(campus, username, password)
                _state.value = LoginState.Success(res.keypass)
            } catch (e: Exception) {
                val msg = when (e) {
                    is HttpException -> when (e.code()) {
                        400 -> "Bad request (400)."
                        401 -> "Unauthorized (401)."
                        404 -> "Not found (404). Check campus."
                        else -> "HTTP ${e.code()} ${e.message()}"
                    }
                    else -> e.message ?: "Unknown error"
                }
                _state.value = LoginState.Error("Login failed: $msg")
            }
        }
    }
}


