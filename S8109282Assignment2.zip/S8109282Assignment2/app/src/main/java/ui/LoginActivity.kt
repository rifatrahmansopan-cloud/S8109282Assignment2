package com.example.s8109282assignment2.ui.login

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge
import com.example.s8109282assignment2.AppConfig
import com.example.s8109282assignment2.databinding.ActivityLoginBinding
import com.example.s8109282assignment2.ui.dashboard.DashboardActivity
import org.koin.androidx.viewmodel.ext.android.viewModel

class LoginActivity : ComponentActivity() {

    private lateinit var binding: ActivityLoginBinding
    private val vm: LoginViewModel by viewModel()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.tvCampusFixed.text = "Campus: ${AppConfig.CAMPUS}${if (AppConfig.MOCK_MODE) " (MOCK MODE)" else ""}"

        binding.btnLogin.setOnClickListener {
            val username = binding.etUsername.text.toString().trim()
            val password = binding.etPassword.text.toString().trim()

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Enter first name and student ID digits only", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            vm.login(AppConfig.CAMPUS, username, password)
        }

        lifecycle.addObserver(
            ObserverStarter(vm.state) { state: LoginState ->
                when (state) {
                    is LoginState.Idle -> binding.progress.visibility = View.GONE
                    is LoginState.Loading -> binding.progress.visibility = View.VISIBLE
                    is LoginState.Success -> {
                        binding.progress.visibility = View.GONE
                        startActivity(Intent(this, DashboardActivity::class.java)
                            .putExtra("keypass", state.keypass))
                    }
                    is LoginState.Error -> {
                        binding.progress.visibility = View.GONE
                        Toast.makeText(this, state.message, Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }
}


