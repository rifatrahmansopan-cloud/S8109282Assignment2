package com.example.s8109282assignment2.di

import com.example.s8109282assignment2.data.BooksRepository
import com.example.s8109282assignment2.data.remote.ApiService
import com.example.s8109282assignment2.ui.dashboard.DashboardViewModel
import com.example.s8109282assignment2.ui.login.LoginViewModel
import com.google.gson.GsonBuilder
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

// Must end with a trailing slash
private const val BASE_URL = "https://nit3213api.onrender.com/"

val appModules = module {

    // OkHttp with BODY logging so you can see full URLs and JSON in Logcat (filter by "OkHttp")
    single {
        OkHttpClient.Builder()
            .addInterceptor(
                HttpLoggingInterceptor().apply {
                    level = HttpLoggingInterceptor.Level.BODY
                }
            )
            .build()
    }

    // Retrofit pointing at the assignment API
    single {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create(GsonBuilder().create()))
            .client(get())
            .build()
    }

    // Typed API service
    single<ApiService> { get<Retrofit>().create(ApiService::class.java) }

    // Repository
    single { BooksRepository(get()) }

    // ViewModels
    viewModel { LoginViewModel(get()) }
    viewModel { DashboardViewModel(get()) }
}
