package com.example.s8109282assignment2.data

import com.example.s8109282assignment2.data.model.BookEntity
import com.example.s8109282assignment2.data.model.DashboardResponse
import com.example.s8109282assignment2.data.model.LoginResponse

object MockData {
    fun login(): LoginResponse = LoginResponse(keypass = "books")
    fun dashboard(): DashboardResponse = DashboardResponse(
        entities = listOf(
            BookEntity(
                property1 = "Clean Code",
                property2 = "Robert C. Martin",
                description = "A handbook of agile software craftsmanship."
            ),
            BookEntity(
                property1 = "Kotlin in Action",
                property2 = "Dmitry Jemerov",
                description = "Practical guide to modern Kotlin features."
            ),
            BookEntity(
                property1 = "Android Programming",
                property2 = "Big Nerd Ranch",
                description = "Hands-on Android app techniques and patterns."
            )
        ),
        entityTotal = 3
    )
}
