package com.example.s8109282assignment2

import android.app.Application
import com.example.s8109282assignment2.di.appModules
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin

class BookshelfApp : Application() {
    override fun onCreate() {
        super.onCreate()
        startKoin {
            androidContext(this@BookshelfApp)
            modules(appModules)
        }
    }
}

