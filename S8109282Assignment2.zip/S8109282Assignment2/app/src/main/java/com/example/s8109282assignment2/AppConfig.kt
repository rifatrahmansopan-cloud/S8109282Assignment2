package com.example.s8109282assignment2

object AppConfig {
    // your campus if/when you try real API
    const val CAMPUS = "sydney"  // or "footscray" or "br"

    // turn mock backend ON/OFF
    const val MOCK_MODE = true
}
