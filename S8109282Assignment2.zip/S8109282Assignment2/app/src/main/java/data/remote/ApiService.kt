package com.example.s8109282assignment2.data.remote

import com.example.s8109282assignment2.data.model.DashboardResponse
import com.example.s8109282assignment2.data.model.LoginRequest
import com.example.s8109282assignment2.data.model.LoginResponse
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

interface ApiService {
    @POST("{campus}/auth")
    suspend fun login(
        @Path("campus") campus: String,
        @Body body: LoginRequest
    ): LoginResponse

    @GET("dashboard/{keypass}")
    suspend fun dashboard(@Path("keypass") keypass: String): DashboardResponse
}
