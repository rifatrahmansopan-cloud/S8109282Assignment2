package com.example.s8109282assignment2.data.model

// Response: { "entities":[{...}], "entityTotal": N }
data class DashboardResponse(
    val entities: List<BookEntity>,
    val entityTotal: Int
)

// Minimal shape used in UI
data class BookEntity(
    val property1: String,   // title
    val property2: String,   // author
    val description: String  // summary
)
