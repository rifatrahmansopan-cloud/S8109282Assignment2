package com.example.s8109282assignment2.data.model

// Body MUST be: {"username":"<firstName>", "password":"<studentIdDigitsOnly>"}
data class LoginRequest(
    val username: String,
    val password: String
)

data class LoginResponse(
    val keypass: String
)
