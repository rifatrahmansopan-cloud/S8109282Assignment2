package com.example.s8109282assignment2.data

import com.example.s8109282assignment2.AppConfig
import com.example.s8109282assignment2.data.model.DashboardResponse
import com.example.s8109282assignment2.data.model.LoginRequest
import com.example.s8109282assignment2.data.model.LoginResponse
import com.example.s8109282assignment2.data.remote.ApiService

class BooksRepository(private val api: ApiService) {

    suspend fun login(campus: String, username: String, password: String): LoginResponse {
        if (AppConfig.MOCK_MODE) return MockData.login()
        return api.login(campus, LoginRequest(username, password))
    }

    suspend fun dashboard(keypass: String): DashboardResponse {
        if (AppConfig.MOCK_MODE) return MockData.dashboard()
        return api.dashboard(keypass)
    }
}

